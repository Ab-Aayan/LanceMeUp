class UnbordingContent {
  String image;
  String title;
  String discription;

  UnbordingContent(
      {required this.image, required this.title, required this.discription});
}

List<UnbordingContent> contents = [
  UnbordingContent(
      title: 'What is Lorem Ipsum 1?',
      image: 'assets/images/Svg1.svg',
      discription:
          "Lorem Ipsum is simple dummy text of the printing and typesetting industry"),
  UnbordingContent(
      title: 'What is Lorem Ipsum 2?',
      image: 'assets/images/svg2.svg',
      discription:
          "Lorem Ipsum is simple dummy text of the printing and typesetting industry"),
  UnbordingContent(
      title: 'What is Lorem Ipsum 3?',
      image: 'assets/images/Svg1.svg',
      discription:
          "Lorem Ipsum is simple dummy text of the printing and typesetting industry"),
  UnbordingContent(
      title: 'What is Lorem Ipsum 4?',
      image: 'assets/images/svg2.svg',
      discription:
          "Lorem Ipsum is simple dummy text of the printing and typesetting industry"),
];
